public class EmployeeManagement {
    public static void main(String[] args) {
        Manager M1 = new Manager("Lovindu", 20, 100000, 5000);
        Executive E1 = new Executive("Sithum", 32, 90000, 10, 200);

        M1.displayDetails();
        E1.displayDetails();
    }
}
