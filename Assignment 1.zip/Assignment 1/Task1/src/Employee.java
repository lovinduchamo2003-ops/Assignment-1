abstract class Employee {
    String name;
    int age;
    double salary;

    // Constructor
    Employee(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    // Method to calculate tax (12.5%)
    public double Tax() {
        return salary * 0.125;
    }

    // Abstract method for Bonus/Overtime
    abstract double Extra();

    // Display details
    public void displayDetails() {
        double tax = Tax();
        double extra = Extra();
        double netSalary = salary - tax + extra;

        System.out.println("----- Employee Details -----");
        System.out.println("Name         : " + name);
        System.out.println("Age          : " + age);
        System.out.println("Basic Salary : " + salary);
        System.out.println("Tax (12.5%)  : " + tax);
        System.out.println("Overtime/Bonus: " + extra);
        System.out.println("Net Salary   : " + netSalary);
        System.out.println("----------------------------\n");
    }
}

// Manager class
class Manager extends Employee {
    double bonus;

    Manager(String name, int age, double salary, double bonus) {
        super(name, age, salary);
        this.bonus = bonus;
    }

    @Override
    double Extra() {
        return bonus;
    }
}

// Executive class
class Executive extends Employee {
    int overtimeHours;
    double overtimeRate;

    Executive(String name, int age, double salary, int overtimeHours, double overtimeRate) {
        super(name, age, salary);
        this.overtimeHours = overtimeHours;
        this.overtimeRate = overtimeRate;
    }

    @Override
    double Extra() {
        return overtimeHours * overtimeRate;
    }
}

